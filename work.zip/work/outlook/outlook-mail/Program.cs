﻿using System.Globalization;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace outlook
{
    class Program
    {
        static void Main(string[] args)
        {
            //sendCalendar();
            deleteCalendar();

        }

        public static void deleteCalendar()
        {
            try
            {
                SmtpClient client = new SmtpClient("smtp-mail.outlook.com");

                client.Port = 587;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                System.Net.NetworkCredential credential = new NetworkCredential("vkhoiit@outlook.com", "675524.Asd");
                client.EnableSsl = true;
                client.Credentials = credential;

                MailMessage message = new MailMessage("vkhoiit@outlook.com", "nhantestcalendar@outlook.com");
                message.Subject = "calendar testing";
                message.Body = "calendar testing";
                var x = TimeZoneInfo.ConvertTime(DateTime.Parse("1/13/2023 3:09:14 PM"), TimeZoneInfo.Local, TimeZoneInfo.FindSystemTimeZoneById(TimeZone.CurrentTimeZone.StandardName));
                var z = TimeZoneInfo.ConvertTime(DateTime.Parse("1/13/2023 3:36:14 PM"), TimeZoneInfo.Local, TimeZoneInfo.FindSystemTimeZoneById(TimeZone.CurrentTimeZone.StandardName));
                // Generate Calendar Invite ---------------------------------------------------
                StringBuilder str = new StringBuilder();
                str.AppendLine("BEGIN:VCALENDAR");
                str.AppendLine("PRODID:-//Schedule a Meeting");
                //str.AppendLine("PRODID:-//CARS//Outlook MIMEDIR//EN");
                str.AppendLine("VERSION:3.0");
                str.AppendLine("METHOD:CANCEL");
                str.AppendLine("BEGIN:VEVENT");
                str.AppendLine("DTSTART:" + x.ToUniversalTime().ToString("yyyyMMdd\\THHmmss\\Z"));
                str.AppendLine("DTEND:" + z.AddMinutes(+60).ToUniversalTime().ToString("yyyyMMdd\\THHmmss\\Z"));
                //str.AppendLine(string.Format("DTSTART:{0:yyyyMMddTHHmmssZ}", DateTime.Now));
                //str.AppendLine(string.Format("DTEND:{0:yyyyMMddTHHmmssZ}", DateTime.Now.AddMinutes(+60)));
                str.AppendLine("LOCATION: " + "abcd");
                str.AppendLine(string.Format("UID:{0}", Guid.NewGuid()));
                str.AppendLine(string.Format("DESCRIPTION:{0}", message.Body));
                str.AppendLine(string.Format("X-ALT-DESC;FMTTYPE=text/html:{0}", message.Body));
                str.AppendLine(string.Format("SUMMARY:{0}", message.Subject));
                str.AppendLine(string.Format("ORGANIZER:MAILTO:{0}", message.From.Address));

                str.AppendLine(string.Format("ATTENDEE;CN=\"{0}\";RSVP=TRUE:mailto:{1}", message.To[0].DisplayName, message.To[0].Address));

                str.AppendLine("BEGIN:VALARM");
                str.AppendLine("TRIGGER:-PT15M");
                str.AppendLine("ACTION:DISPLAY");
                str.AppendLine("COMMENT:Removed Events");
                str.AppendLine("STATUS:CANCELLED");
                str.AppendLine("DESCRIPTION:Reminder");
                str.AppendLine("END:VALARM");
                str.AppendLine("END:VEVENT");
                str.AppendLine("END:VCALENDAR");


                // Attach Calendar Invite ------------------------------------------------------
                //byte[] byteArray = Encoding.ASCII.GetBytes(str.ToString());
                //MemoryStream stream = new MemoryStream(byteArray);

                //Attachment attach = new Attachment(stream, "invite.ics");
                //attach.TransferEncoding = TransferEncoding.QuotedPrintable;
                //message.Attachments.Add(attach);

                ContentType contype = new ContentType("text/calendar");
                contype.CharSet = "UTF-8";
                contype.Parameters.Add("method", "CANCEL");
                //contype.Parameters.Add("name", "invite.ics");

                AlternateView avCal = AlternateView.CreateAlternateViewFromString(str.ToString(), contype);
                avCal.TransferEncoding = TransferEncoding.QuotedPrintable;
                message.AlternateViews.Add(avCal);

                client.Send(message);

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

        }
        public static void sendCalendar()
        {
            try
            {
                SmtpClient client = new SmtpClient("smtp-mail.outlook.com");

                client.Port = 587;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                System.Net.NetworkCredential credential = new NetworkCredential("vkhoiit@outlook.com", "675524.Asd");
                client.EnableSsl = true;
                client.Credentials = credential;

                MailMessage message = new MailMessage("vkhoiit@outlook.com", "nhantestcalendar@outlook.com");
                message.Subject = "calendar testing";
                message.Body = "calendar testing";
                var x = TimeZoneInfo.ConvertTime(DateTime.Parse("1/13/2023 3:09:14 PM"), TimeZoneInfo.Local, TimeZoneInfo.FindSystemTimeZoneById(TimeZone.CurrentTimeZone.StandardName));
                var z = TimeZoneInfo.ConvertTime(DateTime.Parse("1/13/2023 3:36:14 PM"), TimeZoneInfo.Local, TimeZoneInfo.FindSystemTimeZoneById(TimeZone.CurrentTimeZone.StandardName));
                // Generate Calendar Invite ---------------------------------------------------
                StringBuilder str = new StringBuilder();
                str.AppendLine("BEGIN:VCALENDAR");
                str.AppendLine("PRODID:-//Schedule a Meeting");
                str.AppendLine("VERSION:3.0");
                str.AppendLine("METHOD:REQUEST");
                str.AppendLine("BEGIN:VEVENT");
                str.AppendLine("DTSTART:" + x.ToUniversalTime().ToString("yyyyMMdd\\THHmmss\\Z"));
                str.AppendLine("DTEND:" + z.AddMinutes(+60).ToUniversalTime().ToString("yyyyMMdd\\THHmmss\\Z"));
                //str.AppendLine(string.Format("DTSTART:{0:yyyyMMddTHHmmssZ}", DateTime.Now));
                //str.AppendLine(string.Format("DTEND:{0:yyyyMMddTHHmmssZ}", DateTime.Now.AddMinutes(+60)));
                str.AppendLine("LOCATION: " + "abcd");
                str.AppendLine(string.Format("UID:{0}", Guid.NewGuid()));
                str.AppendLine(string.Format("DESCRIPTION:{0}", message.Body));
                str.AppendLine(string.Format("X-ALT-DESC;FMTTYPE=text/html:{0}", message.Body));
                str.AppendLine(string.Format("SUMMARY:{0}", message.Subject));
                str.AppendLine(string.Format("ORGANIZER:MAILTO:{0}", message.From.Address));

                str.AppendLine(string.Format("ATTENDEE;CN=\"{0}\";RSVP=TRUE:mailto:{1}", message.To[0].DisplayName, message.To[0].Address));

                str.AppendLine("BEGIN:VALARM");
                str.AppendLine("TRIGGER:-PT15M");
                str.AppendLine("ACTION:DISPLAY");
                str.AppendLine("DESCRIPTION:Reminder");
                str.AppendLine("END:VALARM");
                str.AppendLine("END:VEVENT");
                str.AppendLine("END:VCALENDAR");


                // Attach Calendar Invite ------------------------------------------------------
                byte[] byteArray = Encoding.ASCII.GetBytes(str.ToString());
                MemoryStream stream = new MemoryStream(byteArray);

                Attachment attach = new Attachment(stream, "invite.ics");
                attach.TransferEncoding = TransferEncoding.QuotedPrintable;
                message.Attachments.Add(attach);

                ContentType contype = new ContentType("text/calendar");
                contype.CharSet = "UTF-8";
                contype.Parameters.Add("method", "REQUEST");
                contype.Parameters.Add("name", "invite.ics");

                AlternateView avCal = AlternateView.CreateAlternateViewFromString(str.ToString(), contype);
                avCal.TransferEncoding = TransferEncoding.QuotedPrintable;
                message.AlternateViews.Add(avCal);

                client.Send(message);

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

        }

    }
}